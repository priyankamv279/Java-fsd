package com.example.demo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
//Junit 4
@RunWith(SpringRunner.class)
@SpringBootTest
class SpringbootDemo41RestfulApplicationTests {
@Autowired
EmployeeService service;
	
	@Test
	public void inserttest() {
		Employee e=new Employee();
		e.setEmpname("satish");  //mocking
		e.setPhono("9999");
	 assertNotNull(service.insert(e));
	}

	
	@Test
	public void deletetest() {
	  assertEquals("deleted id of "+3,service.deletebyid(3));
	}
}


