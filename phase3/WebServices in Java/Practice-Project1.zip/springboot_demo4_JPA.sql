create database db7;
use db7;
show tables;
select * from employee;