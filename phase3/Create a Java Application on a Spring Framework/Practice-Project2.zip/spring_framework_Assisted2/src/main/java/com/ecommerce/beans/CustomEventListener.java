package com.ecommerce.beans;

import org.springframework.context.ApplicationListener;

import com.ecommerce.CustomEvent;

public class CustomEventListener implements ApplicationListener<CustomEvent> {
        
   public void onApplicationEvent(CustomEvent event) {
      System.out.println(event.toString());
   }
}
