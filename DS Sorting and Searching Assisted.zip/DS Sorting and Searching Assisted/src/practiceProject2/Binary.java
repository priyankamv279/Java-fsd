package practiceProject2;

import java.util.Arrays;
import java.util.Scanner;

public class Binary {
	public static void main(String[] args) {
		
		int a[]=new int[] {6,5,11,2,1,7,8,12};//unsorted 
		Arrays.sort(a); // sorting it
		Scanner sc=new Scanner(System.in);
	System.out.println("the sorted array is ");
	for(int i:a) {
	System.out.print(i+"   ");
	}
	System.out.println();
	
	System.out.println("enter the key vlaue to search");//search in the sorted list
		int key=sc.nextInt();
		int flag=0;
		int low=0;
		int high=a.length-1;
		int mid=0;
		while(low<=high) {
		mid=(low+high)/2;
		if(a[mid]==key) {
			flag=1;
			break;
		}
		else if(a[mid]<key){
			low=mid+1;
		}
		else {
			high=mid-1;
		}
		}
		
		if(flag==1) {
			System.out.println("element is found at index "+mid);
		}
		else {
			System.out.println("element is not found ");
		}
	

}
}
