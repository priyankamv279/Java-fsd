package practiceProject1;

import java.util.Arrays;
import java.util.Scanner;

public class LinearDS {
	public static void main(String[] args) {
		
		int a[]=new int[] {6,5,11,2,1,7,8,12};//unsorted 
		Arrays.sort(a); // sorting it 
		Scanner sc=new Scanner(System.in);
		System.out.println("the sorted array is ");
		for(int i:a) {
		System.out.print(i+"   ");
		}
		System.out.println();
		
		System.out.println("enter the key vlaue to search"); //search in the sorted list
		int key=sc.nextInt();
		int flag=0;
		int i=0;
		for(i=0;i<a.length;i++) {
			if(a[i]==key) {
				flag=1;
				break;
			}
			else {
			flag=0;
			}
			
			
		}
		if(flag==1) {
			System.out.println("element is found at index "+i);
		}
		else {
			System.out.println("element is not found ");
		}
	}
}

