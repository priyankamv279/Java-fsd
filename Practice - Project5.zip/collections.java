package Assisted_project;

import java.util.*;
public class collections {
    public static void main(String[] args) {
    	
        // Creating a Vector
        Vector<String> vector = new Vector<>();
        vector.add("dog");
        vector.add("cow");
        vector.add("cat");
        System.out.println("Vector: " + vector);

        // Creating an ArrayList
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("today");
        arrayList.add("tomorrow");
        arrayList.add("yesterday");
        System.out.println("ArrayList: " + arrayList);

        // Creating a LinkedList
        LinkedList<String> linkedList = new LinkedList<>();
        linkedList.add("you");
        linkedList.add("me");
        linkedList.add("they");
        System.out.println("LinkedList: " + linkedList);

        // Creating a HashSet
        HashSet<Integer> hashSet = new HashSet<>();
        hashSet.add(7);
        hashSet.add(8);
        hashSet.add(9);
        System.out.println("HashSet: " + hashSet);

        // Creating a LinkedHashSet
        LinkedHashSet<Integer> linkedHashSet = new LinkedHashSet<>();
        linkedHashSet.add(10);
        linkedHashSet.add(20);
        linkedHashSet.add(30);
        System.out.println("LinkedHashSet: " + linkedHashSet);
    }
}

