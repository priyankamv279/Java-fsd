package assisted_project;

public class Typecasting {
	public static void main(String[] args) {

		
		System.out.println("Implicit Type Casting:-");
		char a='Q';
		System.out.println("Value of a: "+a);
		
		int b= 33;
		System.out.println("Value of b: "+b);

		float c= a;
		System.out.println("Value of c: "+c);

		long d= 55;
		System.out.println("Value of d: "+d);

		double e= a;
		System.out.println("Value of e: "+e);


		
		System.out.println("\nExplicit Type Casting:-");
		double f= 99.999;
		int g=(int)f;
		System.out.println("Value of f: "+f);
		System.out.println("Value of g: "+g);

	}
}



