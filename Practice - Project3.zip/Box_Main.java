package Assisted_project;

public class Box_Main {

	public static void main(String[] args) {

		Box boxobj= new Box();
		int volume = boxobj.boxcal(3,4,6);
		System.out.println(" volume of the box = " +volume);
	}

}
