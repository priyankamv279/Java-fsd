package Assisted_project;

public class Box1 {
	//method with return type and without argument 
	int length;
	int breadth;
	int height;
	
	int boxcal() {
		
		return length * breadth* height;

	}

}
