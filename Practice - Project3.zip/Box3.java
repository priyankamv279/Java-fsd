package Assisted_project;

public class Box3 {
	// method without return and with arguments
	
	void boxcal(int l, int b, int h) {
		int vol = l*b*h;
		System.out.println("volume is " +vol);
	}

}

