package Assisted_project;

public class Box2 {
	// method without return type and arguments
	
	int l,b,h;
	
	void boxcal(){
		int vol = l*b*h;
		System.out.println("Volume is " + vol);
		}

}