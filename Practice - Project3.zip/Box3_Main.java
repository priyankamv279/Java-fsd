package Assisted_project;

public class Box3_Main {
	public static void main(String[] args) {
		
		Box3 boxobj = new Box3();
		boxobj.boxcal(4, 5, 6);
	}
}
