package Assisted_project;

public class Box {
	//method with return type and with argument 
	
	int boxcal(int l, int b, int h) {
		return l*b*h;

}
}