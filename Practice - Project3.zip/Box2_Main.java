package Assisted_project;

public class Box2_Main {

	public static void main(String[] args) {
		
		Box2 boxobj = new Box2();
		boxobj.l= 2;
		boxobj.b= 3;
		boxobj.h= 4;
		
		boxobj.boxcal();
	}

}
