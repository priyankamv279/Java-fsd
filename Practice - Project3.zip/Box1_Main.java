package Assisted_project;

public class Box1_Main {

	public static void main(String[] args) {
		Box1 boxobj= new Box1();
		
		boxobj.length = 2;
		boxobj.breadth = 2;
		boxobj.height = 2;
		
		int volume = boxobj.boxcal();
		
		System.out.println(" volume of the box = " +volume);
	}

}
