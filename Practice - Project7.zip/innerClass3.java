package Assisted_project;

import Assisted_project.innerClass.Inner;

public class innerClass3 {
	public static void main(String[] args) {

		innerClass obj=new innerClass();
		Inner in = obj.new Inner();  
		in.hello();  

		innerClass1 obj1 =new innerClass1 ();  
		obj1.display();  

		innerClass2 i = new innerClass2() {
			public void display() {
				System.out.println("Anonymous Inner Class");
			}
		};
		i.display();

	}

}


