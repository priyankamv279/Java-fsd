package Assisted_project;

abstract class innerClass2 {
	public abstract void display();
}





