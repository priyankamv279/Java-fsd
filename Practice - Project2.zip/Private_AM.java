package assisted_project;

class Person {
	private String name;

	// getter method
	public String getName() {
		return this.name;
	}
	// setter method
	public void setName(String name) {
		this.name= name;
	}
}
