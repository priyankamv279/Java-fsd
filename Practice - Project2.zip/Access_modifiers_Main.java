package assisted_project;

public class Access_modifiers_Main {
	public static void main(String[] args) {
		defaultAccessSpecifier def = new defaultAccessSpecifier();
		def.display();
	}

}
