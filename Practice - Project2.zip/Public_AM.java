package assisted_project;

public class Public_AM {
	public void display() 
    { 
        System.out.println("Public Access Specifiers"); 
    } 

}
