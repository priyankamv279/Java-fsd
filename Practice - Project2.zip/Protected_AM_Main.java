package assisted_project;

public class Protected_AM_Main extends Protected_AM {
    public static void main(String[] args) {

        // create an object of the class
    	Protected_AM pro = new Protected_AM();
         // access protected method
        pro.display();
    }
}
