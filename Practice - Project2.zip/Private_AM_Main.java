package assisted_project;

public class Private_AM_Main {
	public static void main(String[] main){
		Person p = new Person();

		// access the private variable using the getter and setter
		p.setName("Joshua");
		System.out.println(p.getName());
	}
}
