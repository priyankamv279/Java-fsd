package assisted_project;

class Protected_AM {
    // protected method
    protected void display() {
        System.out.println("I am Protected access modifier");
    }
}

