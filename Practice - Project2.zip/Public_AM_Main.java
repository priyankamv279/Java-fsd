package assisted_project;

public class Public_AM_Main {
	public static void main(String[] args) {

		Public_AM obj = new Public_AM(); 
		obj.display();  

	}

}
