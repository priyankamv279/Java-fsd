package assisted_project;

class defaultAccessSpecifier
{ 
  void display() 
     { 
         System.out.println("defalut access specifier"); 
     } 
} 


