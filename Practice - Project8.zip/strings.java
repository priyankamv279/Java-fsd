package Assisted_project;

public class strings {
    public static void main(String[] args) {
        // Create a string
        String originalString = "Hello World!";

        // Convert the string to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(originalString);
        stringBuffer.reverse(); 
          
        // Convert the string to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(originalString);
        stringBuilder.append(" again"); 
        
        // Print the original string, StringBuffer, and StringBuilder
        System.out.println("Original String: " + originalString);
        System.out.println("StringBuffer: " + stringBuffer);
        System.out.println("StringBuilder: " + stringBuilder);
    }
}
