import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { HomepageComponent } from './homepage/homepage.component';
import { UserSignUpComponent } from './user-sign-up/user-sign-up.component';
import { UserDasboardComponent } from './user-dasboard/user-dasboard.component';
import { UserLoginComponent } from './user-login/user-login.component';



const routes: Routes = [
  {path:" ",component:AppComponent},
  {path:"home",component:HomepageComponent},
  {path: 'AadharApp/citizens/signUp',pathMatch: 'full',component: UserSignUpComponent},
  {path: 'AadharApp/citizens/dashboard',pathMatch: 'full',component: UserDasboardComponent},
  {path: 'AadharApp/citizens/logIn',pathMatch: 'full',component: UserLoginComponent}
  ];
  
@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    UserSignUpComponent,
    UserDasboardComponent,
    UserLoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)

  ],
  providers: [
    provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
