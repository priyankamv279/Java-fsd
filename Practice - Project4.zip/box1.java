package assistedProject4;

public class box1 {
	//with parameters constructors
	box1(int l, int b, int h){
		
		int volume = l*b*h;
		System.out.println("volume is " +volume);

	}
}
