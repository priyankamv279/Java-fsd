package assistedProject4;

public class boxMain {
	public static void main(String[] args) {

		Box boxobj = new Box();
	}

}
