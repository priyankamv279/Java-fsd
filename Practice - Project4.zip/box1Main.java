package assistedProject4;

public class box1Main {
	public static void main(String[] args) {

		box1 box= new box1(3,3,3);
	}
}
