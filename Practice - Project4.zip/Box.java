package assistedProject4;

public class Box {

	//default constructors

	
		Box(){

		int length = 2;
		int breadth = 2;
		int height = 2;

		int Volume = length * breadth * height;
		System.out.println("volume is " +Volume);

		}
}