package Assisted_project;
import java.util.*;

public class maps {
    public static void main(String[] args) {
        // Create a HashMap
        HashMap<Integer, String> hashMap = new HashMap<>();
        hashMap.put(1, "Paul");
        hashMap.put(2, "Louis");
        hashMap.put(3, "Candance");

        System.out.println("HashMap:");
        for (Map.Entry<Integer, String> entry : hashMap.entrySet()) {
            System.out.println("Key: " + entry.getKey() + " Value: " + entry.getValue());
        }

        // Create a HashTable
        Hashtable<Integer, String> hashTable = new Hashtable<>();
        hashTable.put(1, "Blake");
        hashTable.put(2, "Dolce");
        hashTable.put(3, "Maddie");

        System.out.println("\nHashTable:");
        for (Map.Entry<Integer, String> entry : hashTable.entrySet()) {
            System.out.println("Key: " + entry.getKey() + " Value: " + entry.getValue());
        }

        // Create a TreeMap
        TreeMap<Integer, String> treeMap = new TreeMap<>();
        treeMap.put(3, "Tia");
        treeMap.put(1, "Obbie");
        treeMap.put(2, "Dan");

        System.out.println("\nTreeMap :");
        for (Map.Entry<Integer, String> entry : treeMap.entrySet()) {
            System.out.println("Key: " + entry.getKey() + " Value: " + entry.getValue());
        }
    }
}


