import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Assisted';
  adminUsername: string = '';
adminPassword: string = '';
userUsername: string = '';
userPassword: string = '';
  
  showAdmin: boolean = false;
  showUser: boolean = false;

  adminLogin() {
    console.log('Admin Login:', this.adminUsername, this.adminPassword);
    // Perform admin login logic
    if (this.adminUsername === 'admin' && this.adminPassword === 'admin') {
      console.log('Admin logged in successfully!');
      // Redirect the user to another page or perform additional actions upon successful login
    } else {
      console.log('Incorrect adminUsername or password. Please try again.');
      // Show an error message or handle unsuccessful login attempts
  }
  }

  userLogin() {
    console.log('User Login:', this.userUsername, this.userPassword);
    // Perform user login logic
    if (this.userUsername === 'user' && this.userPassword === 'user') {
      console.log('User logged in successfully!');
      // Redirect the user to another page or perform additional actions upon successful login
    } else {
      console.log('Incorrect username or password. Please try again.');
      // Show an error message or handle unsuccessful login attempts
    }
  }
}
