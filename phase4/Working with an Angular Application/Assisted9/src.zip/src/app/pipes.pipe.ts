import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pipes'
})
export class PipesPipe implements PipeTransform {
 //ex1.
            // //wish           //param1       //param2
            // transform(value: string, param1:number,param2:number): string {
            //   return value.substring(param1,param2);
          
   //ex2.         
           //person           //wish      
           transform(value: any, param1:any): string {
            if(value.gender=="m"){
             return "Hello Mr. "+value.name+"  "+param1
            }
            else{
             return "Hello Miss. "+value.name+"  "+param1
            }
           }
}
