import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Assisted';
  //predefined pipes  
textdata="Priyanka"
salary=120000
date=new Date()

//customized pipes
//ex1.
wish1="Good Morning"

//ex2.
wish="Good Morning"
person={"name":"bhumi","gender":"f"}

}
