import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Assisted';
  num1: number = 0;
  num2: number = 0;
  opr: string = '+';

  calculate() {
    // Logic to perform calculation based on selected operation
    // No need for explicit logic here as ngSwitch handles it in the HTML
  }
}
